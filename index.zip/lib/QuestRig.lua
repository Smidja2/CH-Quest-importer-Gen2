local V=...
local Skin=V.require('QuestSkin')
local R={};R.__index=R
local FORMAT={{'VertexPosition','float',3},{'VertexTexCoord','float',2},{'VertexColor','float',4},{'VertexShade','float',1}}
local function shade(nx,ny,nz)local l=math.sqrt(nx*nx+ny*ny+nz*nz);if l>0 then nx,ny,nz=nx/l,ny/l,nz/l end;local q=.7725+.06*nx+.225*ny+.11*nz;if q<.46 then q=.46 elseif q>1 then q=1 end;return q,nx,ny,nz end
local WHITE=nil
local function whiteTexture()
  if WHITE then return WHITE end;if not(love and love.image and love.graphics)then return nil end;local ok,d=pcall(love.image.newImageData,1,1);if not ok then return nil end;d:setPixel(0,0,1,1,1,1);local ok2,img=pcall(love.graphics.newImage,d);if ok2 then WHITE=img end;return WHITE
end
local function rowsFor(model,skins,inflate)
  local out={};inflate=inflate or 0
  for _,zi in ipairs(model.indices or {}) do
    local i=zi+1
    local p=model.pos[i]or{0,0,0}
    local n=model.norm[i]or{0,1,0}
    local m=skins[model.joint[i]or 0]
    local x,y,z,a,b,c
    if m then x,y,z=Skin.point(m,p);a,b,c=Skin.dir(m,n) else x,y,z=p[1],p[2],p[3];a,b,c=n[1],n[2],n[3] end
    local sh;a,b,c=a or 0,b or 1,c or 0;sh,a,b,c=shade(a,b,c)
    local uv=model.uv[i]or{0,0}
    local col=model.col[i]or{1,1,1,1}
    -- Quest's actual material information is vertex color. Keep it directly on
    -- the runtime mesh instead of depending on a lossy UV color bake.
    out[#out+1]={x+a*inflate,y+b*inflate,z+c*inflate,uv[1]or 0,uv[2]or 0,
                 col[1]or 1,col[2]or 1,col[3]or 1,col[4]or 1,sh}
  end
  return out
end
function R.new(model)
  if not(model and model._quest and love and love.graphics and love.graphics.newMesh)then return nil end
  local self=setmetatable({model=model,parts={},state=nil,role=nil,clip=nil,frameAt=0,time=0,lo=model.floor or 0,hi=(model.floor or 0)+(model.height or 1),girth=0},R);self.outlineInflate=math.max(.015,(model.height or 1)*.035)
  local _,skins=Skin.pose(model,nil,0);local rows=rowsFor(model,skins,0);local outline=rowsFor(model,skins,self.outlineInflate)
  local ok,mesh=pcall(love.graphics.newMesh,FORMAT,rows,'triangles','dynamic')
  local ok2,om=pcall(love.graphics.newMesh,FORMAT,outline,'triangles','dynamic')
  if not ok or not mesh then return nil,tostring(mesh or 'love.graphics.newMesh failed') end
  -- Quest colors are carried by VertexColor. A 1x1 white texture prevents the
  -- host renderer from multiplying those colors by another baked Quest color.
  local tex=whiteTexture()
  if tex and mesh.setTexture then pcall(mesh.setTexture,mesh,tex)end
  if ok2 and om and tex and om.setTexture then pcall(om.setTexture,om,tex)end
  self.parts[1]={mesh=mesh,outlineMesh=(ok2 and om)or nil,texture=tex,rows=rows,outlineRows=outline};self:skin(0);return self
end
function R:release()for _,p in ipairs(self.parts)do if p.mesh and p.mesh.release then pcall(p.mesh.release,p.mesh)end;if p.outlineMesh and p.outlineMesh.release then pcall(p.outlineMesh.release,p.outlineMesh)end end;self.parts={}end
local function descDuration(model,d)local c=model:_loadClip(d.path);if not c then return 0 end;return (tonumber(c.duration)or((c.frames or 1)/(c.fps or 30)))/math.max(.001,tonumber(d.speed)or 1)end
function R:setState(state)
  local role=self.model.roles and self.model.roles[state];if not(role and role.clips and #role.clips>0)then return false end
  self.state=state;self.role=role;self.time=0;self.done=false;self._choice=nil;self._lastKey=nil;self:skin(0);return true
end
local function active(self)
  local role=self.role;if not role then return nil,0 end;local list=role.clips or {};if #list==0 then return nil,0 end
  if role.choice then if not self._choice then self._choice=math.random(1,#list) end;local d=list[self._choice];local c=self.model:_loadClip(d.path);if not c then return nil,0 end;local fr=(self.time*(c.fps or 30)*(tonumber(d.speed)or 1));if role.loop~=false then fr=fr%math.max(1,c.frames)else fr=math.min(math.max(0,c.frames-1),fr)end;if d.reverse then fr=(c.frames-1)-fr end;return c,fr end
  local total=0;for _,d in ipairs(list)do total=total+descDuration(self.model,d)end;if total<=0 then return nil,0 end;local t=self.time;if role.loop~=false then t=t%total elseif t>=total then t=total-1e-6;self.done=true end
  local at=0;for _,d in ipairs(list)do local dur=descDuration(self.model,d);if t<=at+dur or d==list[#list] then local c=self.model:_loadClip(d.path);if not c then return nil,0 end;local localT=math.max(0,t-at);local fr=localT*(c.fps or 30)*(tonumber(d.speed)or 1);fr=math.min(math.max(0,c.frames-1),fr);if d.reverse then fr=(c.frames-1)-fr end;return c,fr end;at=at+dur end
  return nil,0
end
function R:skin(_)
  local clip,fr=active(self);self.clip=clip;self.frameAt=fr;local _,skins=Skin.pose(self.model,clip,fr);local rows=rowsFor(self.model,skins,0);local outline=rowsFor(self.model,skins,self.outlineInflate);local p=self.parts[1];if p then p.rows=rows;pcall(p.mesh.setVertices,p.mesh,rows);if p.outlineMesh then p.outlineRows=outline;pcall(p.outlineMesh.setVertices,p.outlineMesh,outline)end end
  local lo,hi,g=math.huge,-math.huge,0;for _,v in ipairs(rows)do local x,y,z=v[1],v[2],v[3];if y<lo then lo=y end;if y>hi then hi=y end;local q=math.sqrt(x*x+z*z);if q>g then g=q end end;if lo==math.huge then lo,hi=0,self.model.height or 1 end;self.lo,self.hi,self.girth=lo,hi,g;return true
end
function R:update(dt)self.time=(self.time or 0)+math.max(0,math.min(.1,tonumber(dt)or 0));local c,f=active(self);local key=(c and c.path or '')..':'..tostring(math.floor(f or 0));if key~=self._lastKey then self._lastKey=key;self:skin(0)end;return true end
function R:duration()
  local role=self.role;if not role then return 0 end
  local list=role.clips or{};if #list==0 then return 0 end
  if role.choice then
    if not self._choice then self._choice=math.random(1,#list) end
    return descDuration(self.model,list[self._choice])
  end
  local n=0;for _,d in ipairs(list)do n=n+descDuration(self.model,d)end;return n
end
function R:posedBounds()return self.lo,self.hi,self.girth end
function R:drawPackets(modelMatrix,phase,owner,seq0)local out,seq={},seq0 or 1;for _,p in ipairs(self.parts)do out[#out+1]={schemaVersion=1,cacheKey=('quest:%d:%d'):format(self.model.species or 0,seq),kind='mesh',owner=owner or 'quest.main',phase=phase,sequence=seq,sortKey=('quest:%04d:%04d'):format(self.model.species or 0,seq),material='companion.default',mesh=p.mesh,model=modelMatrix};seq=seq+1 end;return out,seq end
return R
