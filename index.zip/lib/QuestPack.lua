local V=...
local P={cache={},cacheOrder={},textures=setmetatable({}, {__mode='v'}),clips={}}
local IMPORT_ID='pokemon_quest_asset_zip'
local zipIndex=nil
local INDEX=nil
local MAX_MODELS=28

local function u16(s,i)local a,b=s:byte(i,i+1);if not a then return 0 end;return a+(b or 0)*256 end
local function i16(s,i)local v=u16(s,i);if v>=32768 then v=v-65536 end;return v end
local function u32(s,i)local a,b,c,d=s:byte(i,i+3);if not a then return 0 end;return a+(b or 0)*256+(c or 0)*65536+(d or 0)*16777216 end
local function f32(s,i)
  local a,b,c,d=s:byte(i,i+3);if not d then return 0 end
  local u=a+b*256+c*65536+d*16777216;local sign=1
  if u>=2147483648 then sign=-1;u=u-2147483648 end
  local e=math.floor(u/8388608);local m=u-e*8388608
  if e==255 then return m==0 and sign*math.huge or 0/0 end
  if e==0 then return m==0 and 0 or sign*(m/8388608)*2^-126 end
  return sign*(1+m/8388608)*2^(e-127)
end

local function buildZipIndex()
  if zipIndex then return zipIndex end
  zipIndex={}
  if not(V.mod and V.mod.imports and type(V.mod.imports.info)=='function')then return zipIndex end
  local info=V.mod.imports:info(IMPORT_ID);if not info then return zipIndex end
  local size=tonumber(info.size or info.length or 0)or 0;if size<=0 then return zipIndex end
  local tailN=math.min(size,66000);local tail=V.mod.imports:read(IMPORT_ID,size-tailN,tailN);if not tail then return zipIndex end
  local e;for i=#tail-21,1,-1 do if tail:sub(i,i+3)=='PK\005\006'then e=i;break end end;if not e then return zipIndex end
  local count=u16(tail,e+10);local cdSize=u32(tail,e+12);local cdOff=u32(tail,e+16);if cdSize<=0 then return zipIndex end
  local cd=V.mod.imports:read(IMPORT_ID,cdOff,cdSize);if not cd then return zipIndex end
  local p=1
  for _=1,count do
    if p+45>#cd or cd:sub(p,p+3)~='PK\001\002'then break end
    local method=u16(cd,p+10);local cs=u32(cd,p+20);local nl=u16(cd,p+28);local xl=u16(cd,p+30);local cl=u16(cd,p+32);local lo=u32(cd,p+42)
    local name=cd:sub(p+46,p+45+nl);if name and #name>0 then zipIndex[name]={method=method,csize=cs,localOff=lo}end
    p=p+46+nl+xl+cl
  end
  return zipIndex
end
local function zipRead(path)
  local e=buildZipIndex()[path];if not e then return nil end
  local h=V.mod.imports:read(IMPORT_ID,e.localOff,30);if not h or h:sub(1,4)~='PK\003\004'then return nil end
  local nl=u16(h,27);local xl=u16(h,29);local raw=V.mod.imports:read(IMPORT_ID,e.localOff+30+nl+xl,e.csize);if not raw then return nil end
  if e.method==0 then return raw end
  if e.method==8 and love and love.data and type(love.data.decompress)=='function' then local ok,out=pcall(love.data.decompress,'string','deflate',raw);if ok then return out end end
  return nil
end
local function loadLua(path)
  local b=zipRead(path);if not b then return nil,'missing '..path end
  local f,e=load(b,'@questpack/'..path);if not f then return nil,e end
  local ok,v=pcall(f);if not ok then return nil,v end;return v
end
local function getIndex()
  if INDEX then return INDEX end
  local v,e=loadLua('quest/index.lua');if not v then return nil,e end;INDEX=v;return INDEX
end
local function image(rel)
  if not rel then return nil end;if P.textures[rel] then return P.textures[rel] end
  local b=zipRead(rel);if not b then return nil end
  local ok,fd=pcall(love.filesystem.newFileData,b,rel);if not ok then return nil end
  local ok2,img=pcall(love.graphics.newImage,fd);if not ok2 then return nil end
  if img.setFilter then pcall(img.setFilter,img,'nearest','nearest') end;P.textures[rel]=img;return img
end
local function parseModel(s)
  if type(s)~='string' or #s<44 or s:sub(1,4)~='QMD1' then return nil,'bad Quest model payload' end
  local p=5;local ver=u16(s,p);p=p+2;if ver~=1 then return nil,'unsupported Quest model version' end
  local nt=u16(s,p);p=p+2;local nv=u32(s,p);p=p+4;local ns=u16(s,p);p=p+2;local nb=u16(s,p);p=p+2
  local root=i16(s,p);p=p+2;local render=i16(s,p);p=p+2
  local min={f32(s,p),f32(s,p+4),f32(s,p+8)};p=p+12;local max={f32(s,p),f32(s,p+4),f32(s,p+8)};p=p+12
  local tr={};local hashToIndex={}
  for i=1,nt do
    local parent=i16(s,p);p=p+2;p=p+2;local hash=u32(s,p);p=p+4
    local pos={f32(s,p),f32(s,p+4),f32(s,p+8)};p=p+12
    local rot={f32(s,p),f32(s,p+4),f32(s,p+8),f32(s,p+12)};p=p+16
    local sca={f32(s,p),f32(s,p+4),f32(s,p+8)};p=p+12
    tr[i]={parent=parent>=0 and parent+1 or 0,hash=hash,p=pos,r=rot,s=sca};hashToIndex[hash]=i
  end
  local pos,norm,col,uv,joint={},{},{},{},{}
  for i=1,nv do
    pos[i]={f32(s,p),f32(s,p+4),f32(s,p+8)};p=p+12
    norm[i]={f32(s,p),f32(s,p+4),f32(s,p+8)};p=p+12
    local r,g,b,a=s:byte(p,p+3);p=p+4;col[i]={(r or 255)/255,(g or 255)/255,(b or 255)/255,(a or 255)/255}
    uv[i]={f32(s,p),f32(s,p+4)};p=p+8;joint[i]=s:byte(p) or 0;p=p+4
  end
  local indices={};for _=1,ns do local n=u32(s,p);p=p+4;for _=1,n do indices[#indices+1]=u32(s,p);p=p+4 end end
  local bones,bind={},{}
  for i=1,nb do local ti=i16(s,p);p=p+2;p=p+2;bones[i]=ti>=0 and ti+1 or 0;local m={};for k=1,16 do m[k]=f32(s,p);p=p+4 end;bind[i]=m end
  return {transforms=tr,hashToIndex=hashToIndex,nv=nv,pos=pos,norm=norm,col=col,uv=uv,joint=joint,indices=indices,bones=bones,bind=bind,root=root>=0 and root+1 or 0,render=render>=0 and render+1 or 0,min=min,max=max,height=math.max(.001,max[2]-min[2]),floor=min[2]}
end
local function parseClip(s,path)
  if type(s)~='string' or #s<20 or s:sub(1,4)~='QAN1' then return nil,'bad Quest animation '..tostring(path) end
  local p=5;local ver=u16(s,p);p=p+2;if ver~=1 then return nil,'unsupported Quest animation version' end
  local fps=u16(s,p);p=p+2;local frames=u16(s,p);p=p+2;local count=u16(s,p);p=p+2;local duration=f32(s,p);p=p+4;local loop=(s:byte(p) or 0)~=0;p=p+4
  local tracks={};for _=1,count do local h=u32(s,p);p=p+4;local attr=s:byte(p)or 0;local dim=s:byte(p+1)or 0;p=p+4;tracks[#tracks+1]={hash=h,attr=attr,dim=dim,offset=p};p=p+frames*dim*4 end
  return {path=path,data=s,fps=fps,frames=frames,duration=duration,loop=loop,tracks=tracks}
end
local function touch(key)
  for i=#P.cacheOrder,1,-1 do if P.cacheOrder[i]==key then table.remove(P.cacheOrder,i)break end end;P.cacheOrder[#P.cacheOrder+1]=key
  while #P.cacheOrder>MAX_MODELS do local old=table.remove(P.cacheOrder,1);if old~=key then P.cache[old]=nil end end
end
function P._loadClip(path)
  if not path then return nil end;if P.clips[path] then return P.clips[path] end
  local s=zipRead(path);if not s then return nil end;local c=parseClip(s,path);P.clips[path]=c;return c
end
local function rowFor(species)
  local I=getIndex()
  local n=math.floor(tonumber(species)or 0)
  if not(I and I.species) then return nil end
  -- v1.02 accepts both correct numeric Lua keys and v1.00/v1.01 stringified keys.
  return I.species[n] or I.species[tostring(n)]
end
function P.variants(species)
  local row=rowFor(species);local out={};if row and row.variants then for k in pairs(row.variants)do out[#out+1]=k end;table.sort(out)end;return out
end
function P.hasVariant(species,variant)
  local row=rowFor(species);return row and row.variants and row.variants[tostring(variant or 'normal')]~=nil or false
end
function P.load(species,variant)
  species=math.floor(tonumber(species)or 0);variant=tostring(variant or 'normal');local key=tostring(species)..':'..variant
  if P.cache[key] then touch(key);return P.cache[key] end
  local I,e=getIndex();if not I then return nil,e end;local row=rowFor(species);local desc=row and row.variants and row.variants[variant]
  if not desc then return nil,('Quest model unavailable for National Dex #%03d variant %s'):format(species,variant) end
  local raw=zipRead(desc.model);if not raw then return nil,'missing '..tostring(desc.model) end;local D,why=parseModel(raw);if not D then return nil,why end
  D.species=species;D.variant=variant;D.pm=desc.pm;D.name=desc.name or row.name or ('Pokemon '..species);D.texture=image(desc.texture);D.roles=I.roles or {};D.states={};D.anims={}
  for state,role in pairs(D.roles) do if role and role.clips and #role.clips>0 then D.states[state]=true;D.anims[state]=role end end
  D._quest=true;D.baseFloor=D.floor
  function D:_loadClip(path)return P._loadClip(path)end
  P.cache[key]=D;touch(key);return D
end
function P.available(species)local row=rowFor(species);return row and row.variants and row.variants.normal~=nil or false end
function P.readAsset(path)return zipRead(path)end
function P.invalidate()P.cache={};P.cacheOrder={};P.clips={};zipIndex=nil;INDEX=nil end
return P
