local V=...
local S={}
local function mul(a,b)local o={};for r=0,3 do for c=1,4 do o[r*4+c]=a[r*4+1]*b[c]+a[r*4+2]*b[4+c]+a[r*4+3]*b[8+c]+a[r*4+4]*b[12+c] end end;return o end
local function trans(v)return{1,0,0,v[1],0,1,0,v[2],0,0,1,v[3],0,0,0,1}end
local function scl(v)return{v[1],0,0,0,0,v[2],0,0,0,0,v[3],0,0,0,0,1}end
local function quat(q)local x,y,z,w=q[1],q[2],q[3],q[4];local n=math.sqrt(x*x+y*y+z*z+w*w);if n>0 then x,y,z,w=x/n,y/n,z/n,w/n end;return{1-2*(y*y+z*z),2*(x*y-w*z),2*(x*z+w*y),0,2*(x*y+w*z),1-2*(x*x+z*z),2*(y*z-w*x),0,2*(x*z-w*y),2*(y*z+w*x),1-2*(x*x+y*y),0,0,0,0,1}end
local function f32(s,i)local a,b,c,d=s:byte(i,i+3);if not d then return 0 end;local u=a+b*256+c*65536+d*16777216;local sign=1;if u>=2147483648 then sign=-1;u=u-2147483648 end;local e=math.floor(u/8388608);local m=u-e*8388608;if e==255 then return m==0 and sign*math.huge or 0/0 end;if e==0 then return m==0 and 0 or sign*(m/8388608)*2^-126 end;return sign*(1+m/8388608)*2^(e-127)end
function S.point(m,p)return m[1]*p[1]+m[2]*p[2]+m[3]*p[3]+m[4],m[5]*p[1]+m[6]*p[2]+m[7]*p[3]+m[8],m[9]*p[1]+m[10]*p[2]+m[11]*p[3]+m[12]end
function S.dir(m,p)return m[1]*p[1]+m[2]*p[2]+m[3]*p[3],m[5]*p[1]+m[6]*p[2]+m[7]*p[3],m[9]*p[1]+m[10]*p[2]+m[11]*p[3]end
local I={1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1}
local function sample(clip,t,frame)
  local f=math.max(0,math.min((clip.frames or 1)-1,math.floor(frame or 0)));local p=t.offset+f*t.dim*4;local v={};for k=1,t.dim do v[k]=f32(clip.data,p+(k-1)*4) end;return v
end
function S.pose(model,clip,frame)
  local overrides={}
  if clip then for _,t in ipairs(clip.tracks or {}) do local ti=model.hashToIndex[t.hash];if ti then local q=overrides[ti] or {};overrides[ti]=q;if t.attr==1 then q.p=sample(clip,t,frame) elseif t.attr==2 then q.r=sample(clip,t,frame) elseif t.attr==3 then q.s=sample(clip,t,frame) end end end end
  local world={}
  for i,t in ipairs(model.transforms or {}) do local o=overrides[i] or {};local l=mul(mul(trans(o.p or t.p),quat(o.r or t.r)),scl(o.s or t.s));world[i]=(t.parent and t.parent>0) and mul(world[t.parent],l) or l end
  local skins={}
  for bi,ti in ipairs(model.bones or {}) do local w=(ti and ti>0 and world[ti]) or I;skins[bi-1]=mul(w,(model.bind and model.bind[bi]) or I) end
  return world,skins
end
return S
