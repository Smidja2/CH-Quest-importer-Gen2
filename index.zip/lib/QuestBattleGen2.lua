local V=...
local B={}
local installed=false
local slots={player=nil,enemy=nil}
local lastBattler={player=nil,enemy=nil}
local API,hostMod,Voxel3D,BattleScene,OverworldBattle
local previousBattleSetting=nil
local lastTime=nil
local BLACK_TEXTURE=nil

local function log(level,fmt,...)
  local L=V.log
  if L and type(L[level])=="function" then pcall(L[level],L,fmt,...) end
end

local function blackTexture()
  if BLACK_TEXTURE then return BLACK_TEXTURE end
  if not (love and love.image and love.graphics and love.image.newImageData and love.graphics.newImage) then return nil end
  local ok,data=pcall(love.image.newImageData,1,1)
  if not ok or not data then return nil end
  pcall(data.setPixel,data,0,0,0,0,0,1)
  local ok2,img=pcall(love.graphics.newImage,data)
  if ok2 then BLACK_TEXTURE=img end
  return BLACK_TEXTURE
end

local function battleEnabled()
  if API and type(API.battleSceneEnabled)=="function" then
    local ok,v=pcall(API.battleSceneEnabled)
    if ok then return v~=false end
  end
  return true
end

local function outlineEnabled()
  if API and type(API.outlineEnabled)=="function" then
    local ok,v=pcall(API.outlineEnabled)
    if ok then return v==true end
  end
  return false
end

local function currentBattle()
  local ok,G=pcall(require,"src.core.Game")
  if not ok or not G then return nil end
  local top=G.stack and G.stack.top and G.stack:top() or nil
  if top and top.player and top.enemy then return top end
  return nil
end

local function battlerFor(battle,side)
  if not battle then return nil end
  return side=="player" and battle.player or battle.enemy
end

local function dexOf(battle,battler)
  local game=(battle and battle.game) or nil
  local species=battler and battler.mon and battler.mon.species
  local def=game and game.data and game.data.pokemon and species and game.data.pokemon[species]
  return def and def.dex or tonumber(species)
end

local function showingTrainer(battle,side)
  if not battle then return false end
  if side=="enemy" then return battle.showEnemyTrainer and battle.trainerPic and true or false end
  return battle.showPlayerBack and battle.playerBackPic and true or false
end

local function sideVisible(battle,side)
  if not battle or showingTrainer(battle,side) then return false end
  local b=battlerFor(battle,side)
  if not b then return false end
  if side=="enemy" then return not battle.enemyHidden and not battle.enemySendingOut end
  return not battle.safari and not battle.demo and not battle.sendingOut
end

local function destroySide(side)
  local a=slots[side]
  if a then pcall(a.destroy,a) end
  slots[side]=nil
  lastBattler[side]=nil
end

local function syncSide(battle,side)
  if not battleEnabled() then destroySide(side);return nil end
  local battler=battlerFor(battle,side)
  if not battler or showingTrainer(battle,side) then destroySide(side);return nil end
  local dex=dexOf(battle,battler)
  if not dex then destroySide(side);return nil end
  local a=slots[side]
  if not a or not a.model or a.model.species~=dex or lastBattler[side]~=battler then
    destroySide(side)
    local made,err=API.createActor(dex,{manual=true,visible=true,worldShadow=false})
    if not made then log("warn","Quest Gen2 battle model unavailable for %s dex=%s: %s",side,tostring(dex),tostring(err));return nil end
    a=made;slots[side]=a;lastBattler[side]=battler
    a:setAnimation("idle")
  end
  local vis=sideVisible(battle,side)
  local was=a._battleWasVisible==true
  a:setVisible(vis)
  if vis and not was then a:setAnimation("battle_start");a._manualTickTime=nil end
  a._battleWasVisible=vis
  return a
end

local function step(battle)
  syncSide(battle,"enemy");syncSide(battle,"player")
  local now=(love and love.timer and love.timer.getTime and love.timer.getTime()) or os.clock()
  local dt=lastTime and math.max(0,math.min(.1,now-lastTime)) or 1/60
  lastTime=now
  for _,side in ipairs({"enemy","player"}) do
    local a=slots[side]
    if a then
      if a.tickNow then pcall(a.tickNow,a) else pcall(a.update,a,dt) end
    end
  end
end

local function drawActor(actor,side,arena,ctx)
  if not (actor and actor.visible and arena and ctx and Voxel3D and type(Voxel3D.draw)=="function") then return false end
  local own=side=="player" and arena.player or arena.enemy
  local other=side=="player" and arena.enemy or arena.player
  if not own then return false end
  local fx,fz=0,(side=="player" and -1 or 1)
  if other then fx,fz=other[1]-own[1],other[2]-own[2] end
  local yaw=math.atan2(fx,fz)
  actor:setPosition(own[1],tonumber(ctx.groundY) or 0,own[2])
  actor:setYaw(yaw)
  if actor.tickNow then pcall(actor.tickNow,actor) end
  if actor.rig and actor.rig.skin then pcall(actor.rig.skin,actor.rig,yaw) end
  local matrix=actor:matrix()
  if type(Voxel3D.seams)=="function" then pcall(Voxel3D.seams,false) end
  if type(Voxel3D.glass)=="function" then pcall(Voxel3D.glass,false) end
  local black=blackTexture()
  if outlineEnabled() and black and love and love.graphics and love.graphics.setDepthMode then
    pcall(love.graphics.setDepthMode,"lequal",false)
    for _,part in ipairs(actor.rig.parts or {}) do
      if part.outlineMesh then pcall(Voxel3D.draw,part.outlineMesh,black,matrix,0,matrix) end
    end
    pcall(love.graphics.setDepthMode,"lequal",true)
  end
  local drew=false
  for _,part in ipairs(actor.rig.parts or {}) do
    if part.mesh and part.texture then
      local ok=pcall(Voxel3D.draw,part.mesh,part.texture,matrix,0,matrix)
      if ok then drew=true end
    end
  end
  if type(Voxel3D.glass)=="function" then pcall(Voxel3D.glass,true) end
  if type(Voxel3D.seams)=="function" then pcall(Voxel3D.seams,true) end
  return drew
end

local function sideOf(self,battler)
  if not self or not battler then return nil end
  if battler==self.player then return "player" end
  if battler==self.enemy then return "enemy" end
end

local function moveAnim(...)
  local args={...}
  for _,v in ipairs(args) do
    if type(v)=="table" then
      local c=v.category or v.damageClass or v.damage_class or v.kind or v.class
      c=c and tostring(c):lower() or nil
      if c and c:find("special",1,true) then return "special" end
      if c and (c:find("status",1,true) or c:find("other",1,true)) then return "status" end
      if c and (c:find("physical",1,true) or c:find("attack",1,true)) then return "physical" end
    elseif type(v)=="string" then
      local c=v:lower();if c=="special" or c=="physical" or c=="status" then return c end
    end
  end
  return "attack"
end

local function installHooks()
  local ok,BattleState=pcall(require,"src.battle.BattleState")
  if not (ok and BattleState) or BattleState.questGen2Hook then return end
  BattleState.questGen2Hook=true
  if type(BattleState.performMove)=="function" then
    local inner=BattleState.performMove
    BattleState.performMove=function(self,user,...)
      local side=sideOf(self,user);local a=battleEnabled() and side and slots[side]
      if a then pcall(a.setAnimation,a,moveAnim(...)) end
      return inner(self,user,...)
    end
  end
  if type(BattleState.startGrowIn)=="function" then
    local inner=BattleState.startGrowIn
    BattleState.startGrowIn=function(self,battler,...)
      local side=sideOf(self,battler);local a=battleEnabled() and side and slots[side]
      if a then pcall(a.setAnimation,a,"battle_start") end
      return inner(self,battler,...)
    end
  end
  if type(BattleState.onFaint)=="function" then
    local inner=BattleState.onFaint
    BattleState.onFaint=function(self,battler,...)
      local side=sideOf(self,battler);local a=battleEnabled() and side and slots[side]
      if a then pcall(a.setAnimation,a,"faint") end
      return inner(self,battler,...)
    end
  end
end

local function readSetting()
  local st=OverworldBattle and OverworldBattle.setting
  if st and type(st.get)=="function" then
    local ok,v=pcall(st.get,st);if ok then return v end
  end
end
local function writeSetting(v)
  local st=OverworldBattle and OverworldBattle.setting
  if st and type(st.set)=="function" then return pcall(st.set,st,v) end
  return false
end
local function syncBattleSceneSetting()
  if not OverworldBattle then return end
  if battleEnabled() then writeSetting(true) else writeSetting(previousBattleSetting) end
end

function B.install(host,api)
  if installed then return true end
  hostMod,API=host,api
  local lib=host and host.exports and host.exports.lib
  if not (lib and type(lib.require)=="function") then return false,"Gen2 Battle Art lib export unavailable" end
  local okv,v=pcall(lib.require,"Voxel3D");if not okv or not v then return false,"Gen2 Voxel3D unavailable" end
  local okb,bs=pcall(lib.require,"BattleScene");if not okb or not bs or type(bs.render)~="function" then return false,"Gen2 BattleScene unavailable" end
  local oko,owb=pcall(lib.require,"OverworldBattle");if not oko or not owb then return false,"Gen2 OverworldBattle unavailable" end
  Voxel3D,BattleScene,OverworldBattle=v,bs,owb
  previousBattleSetting=readSetting()
  syncBattleSceneSetting()

  local original=BattleScene.render
  BattleScene.render=function(state,arena,textures,token,drawActors)
    if not battleEnabled() then
      destroySide("player");destroySide("enemy");lastTime=nil
      return original(state,arena,textures,token,drawActors)
    end
    -- An external realtime provider already owns this battle; leave it untouched.
    if drawActors then return original(state,arena,textures,token,drawActors) end
    local battle=currentBattle()
    if not battle then return original(state,arena,textures,token,nil) end
    step(battle)
    local replaceP=slots.player and slots.player.visible
    local replaceE=slots.enemy and slots.enemy.visible
    -- Keep the engine's trainer/send-out cards until both Pokemon are actually out.
    if not (replaceP and replaceE) then return original(state,arena,textures,token,nil) end
    local function provider(ctx)
      drawActor(slots.enemy,"enemy",arena,ctx)
      drawActor(slots.player,"player",arena,ctx)
    end
    return original(state,arena,textures,token,provider)
  end

  installHooks()
  local mod=V.mod
  if mod and mod.events and type(mod.events.on)=="function" then
    mod.events:on("mod.options_changed",function(payload)
      if type(payload)=="table" and payload.mod==mod.id and payload.key=="quest_battle_scene" then
        syncBattleSceneSetting()
      end
    end)
  end
  installed=true
  log("info","Quest Gen2 Battle Art staged-battle integration installed")
  return true
end

return B
