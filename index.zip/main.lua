local mod = ...
local function liveGame()
  local g=mod and mod.game
  return type(g)=="table" and g or nil
end
local Game=setmetatable({}, {
  __index=function(_,k)
    local g=liveGame()
    if not g then return nil end
    if k=="overworld" then return g.overworld or g.world end
    return g[k]
  end,
  __newindex=function(_,k,v)
    local g=liveGame(); if g then g[k]=v end
  end
})
local V={mod=mod,path=mod.path}
local modules={}
local function chunkFor(rel)
  local source=mod:read(rel)
  if not source then error("QUEST_MAIN: missing "..rel,0) end
  local chunk,err=load(source,"@"..mod.path.."/"..rel)
  if not chunk then error("QUEST_MAIN compile error in "..rel..": "..tostring(err),0) end
  return chunk
end
function V.require(name)
  if modules[name]~=nil then return modules[name] end
  local value=chunkFor("lib/"..name..".lua")(V)
  modules[name]=value
  return value
end
V.log = mod.log

local Pack=V.require("QuestPack")
local Rig=V.require("QuestRig")
local Mat4=V.require("Mat4")
local actors={}

-- Legacy contact-shadow helpers are retained only for backward ABI safety.
-- v0.7.18 never submits that ellipse: imported overworld Pokemon now rely on
-- Battle Art's directional sun ShadowMap, matching the player/world lighting.
local OVERWORLD_SHADOW_FORMAT={
  {"VertexPosition","float",3},
  {"VertexTexCoord","float",2},
  {"VertexShade","float",1},
}
local overworldShadowImage=nil
local function ensureOverworldShadowImage()
  if overworldShadowImage then return overworldShadowImage end
  if not (love and love.image and love.graphics and love.image.newImageData and love.graphics.newImage) then return nil end
  local size=48
  local ok,data=pcall(love.image.newImageData,size,size)
  if not ok or not data then return nil end
  for y=0,size-1 do
    for x=0,size-1 do
      local dx=((x+.5)/size)*2-1
      local dz=((y+.5)/size)*2-1
      local d=dx*dx+dz*dz
      local a=0
      if d<1 then
        -- Battle Art's Voxel3D shader discards texels below alpha .5.  The old
        -- .42 maximum therefore made the entire fallback shadow invisible.
        -- Keep most of the ellipse above the cutoff and fade only at the rim.
        local q=math.max(0,1-d)
        a=.72*(q^0.12)
      end
      data:setPixel(x,y,0,0,0,a)
    end
  end
  local okImg,img=pcall(love.graphics.newImage,data)
  if not okImg or not img then return nil end
  if img.setFilter then pcall(img.setFilter,img,"linear","linear") end
  overworldShadowImage=img
  return img
end

-- Unified Quest option: renderer-provided model shadows.
local SHADOW_KEY="quest_shadow"
local OUTLINE_KEY="quest_toon_outline"
local BATTLE_SCENE_KEY="quest_battle_scene"
local SMOOTH_KEY="quest_model_smoothing"
local function storedOption(key,default)
  local loader=Game and Game.mods
  local stored=loader and loader.modOptions and loader.modOptions[mod.id]
  if stored and stored[key]~=nil then return stored[key] end

  local opts=Game and Game.save and Game.save.options
  stored=opts and opts.modOptions and opts.modOptions[mod.id]
  if stored and stored[key]~=nil then return stored[key] end

  return default
end

local function shadowEnabled()
  local v=storedOption(SHADOW_KEY,true)
  return v~=false and v~=0 and v~="OFF" and v~="NO"
end

local function outlineEnabled()
  local v=storedOption(OUTLINE_KEY,false)
  return v~=false and v~=0 and v~="OFF" and v~="NO"
end
local function battleSceneEnabled()
  local v=storedOption(BATTLE_SCENE_KEY,true)
  return v~=false and v~=0 and v~="OFF" and v~="NO"
end
local function modelSmoothingEnabled()
  local v=storedOption(SMOOTH_KEY,false)
  return v==true or v==1 or v=="ON" or v=="YES" or v=="SMOOTH"
end
local function setShadow(game,value)
  local opts=game and game.save and game.save.options
  if opts then
    opts.modOptions=opts.modOptions or {}; opts.modOptions[mod.id]=opts.modOptions[mod.id] or {}
    opts.modOptions[mod.id][SHADOW_KEY]=value
  end
  local loader=game and game.mods
  if loader then
    loader.modOptions=loader.modOptions or {}; loader.modOptions[mod.id]=loader.modOptions[mod.id] or {}
    loader.modOptions[mod.id][SHADOW_KEY]=value
  end
  if game and game.writeOptions then pcall(game.writeOptions,game) end
end

local nextId=1
local companionHandle=nil
local rendererMod=nil
local rendererId=nil
local Voxel3D=nil
local realWorldShadowBridge=false
local battleArtForkPresent=false

-- Lightweight companion adapter for renderers that expose Voxel3D but do not
-- expose the native voxel_companion service (PotatoVoxel, Ascendant, Gen2).
local localSpecs={}
local localLastWorld=nil
local localCompanion=nil

local function liveGame()
  local ok,g=pcall(function() return mod.game end)
  if ok and type(g)=="table" then return g end
  local ok2,G=pcall(require,"src.core.Game")
  if ok2 and type(G)=="table" then return G end
  return nil
end

local function worldSnapshot()
  local g=liveGame()
  local ow=g and (g.overworld or g.world)
  local map=ow and ow.map
  local p=ow and ow.player
  if not (map and p) then return nil end

  -- Gen1Recomp/Potato entities are fundamentally 2D: px/py are world-pixel
  -- coordinates and cellX/cellY are map cells.  Quest companion mods use
  -- x/z for the horizontal ground plane and y strictly for vertical height.
  -- Never feed the engine's map-Y into Quest's vertical Y axis.
  local cx=tonumber(p.cellX)
  local cz=tonumber(p.cellY) or tonumber(p.cellZ)
  local px=tonumber(p.px)
  local pz=tonumber(p.py)
  local x=tonumber(p.x)
  local z=tonumber(p.z)
  if px~=nil then x=px+8 elseif x==nil and cx~=nil then x=cx*16+8 end
  if pz~=nil then z=pz+8 elseif z==nil and cz~=nil then z=cz*16+8 end

  return {
    id=tostring(map.id or map.name or map),
    map=map,
    player={
      x=x or 0,
      y=tonumber(p.worldY) or tonumber(p.height) or 0,
      z=z or 0,
      cellX=cx,
      cellY=cz, -- compatibility alias for older specs
      cellZ=cz, -- Quest follower/wild/flying ground-plane axis
      facing=p.facing or "down",
    },
  }
end

local function makeLocalCompanion(host,lib)
  if localCompanion then return localCompanion end
  local OverworldBattle=nil
  if lib and type(lib.require)=="function" then
    local okb,b=pcall(lib.require,"OverworldBattle")
    if okb then OverworldBattle=b end
  end
  localCompanion={api=1}
  function localCompanion.register(spec)
    if type(spec)~="table" then return nil,"invalid companion spec" end
    localSpecs[#localSpecs+1]=spec
    table.sort(localSpecs,function(a,b) return (tonumber(a.priority) or 0)<(tonumber(b.priority) or 0) end)
    if type(spec.attach)=="function" then pcall(spec.attach,{}) end
    local handle={}
    function handle.dispose()
      for i=#localSpecs,1,-1 do if localSpecs[i]==spec then table.remove(localSpecs,i) break end end
      if type(spec.dispose)=="function" then pcall(spec.dispose) end
    end
    return handle
  end

  if Voxel3D and type(Voxel3D.endScene)=="function" and not Voxel3D.questUniversalEndScene then
    Voxel3D.questUniversalEndScene=true
    local inner=Voxel3D.endScene
    Voxel3D.endScene=function(...)
      local staged=false
      if OverworldBattle and type(OverworldBattle.arena)=="function" then
        local oka,a=pcall(OverworldBattle.arena)
        staged=oka and a~=nil
      end
      if not staged then
        local world=worldSnapshot()
        if world then
          if localLastWorld~=world.id then
            localLastWorld=world.id
            for _,spec in ipairs(localSpecs) do if type(spec.worldChanged)=="function" then pcall(spec.worldChanged,world) end end
          end
          local dt=1/60
          local okdt,g=pcall(function() return liveGame() end)
          if okdt and g then
            dt=tonumber(g.dt) or tonumber(g.deltaTime) or dt
          end
          dt=math.max(0,math.min(0.1,dt))
          local context={world=world,frame={dt=dt}}
          for _,spec in ipairs(localSpecs) do
            if type(spec.update)=="function" then pcall(spec.update,context.frame) end
            -- Gameplay companion specs draw themselves directly through Voxel3D.
            -- Skip the importer's generic packet renderer to avoid duplicate actors.
            if spec.id~="quest.main" and spec.id~="quest.importer" and spec.render and type(spec.render.opaque_after_terrain)=="function" then
              pcall(spec.render.opaque_after_terrain,context)
            end
          end
        end
      end
      return inner(...)
    end
  end
  return localCompanion
end

local function hostApi()
  if not (mod and type(mod.find)=="function") then return nil,"mod.find unavailable" end
  for _,id in ipairs({"BATTLE_ART_VOXEL_GEN2","BATTLE_ART_VOXEL_FORK","potato_voxel","VOXEL_ASCENDANT","DRAMALESS_SHAPE"}) do
    local ok,host=pcall(mod.find,id)
    if ok and host then
      if id=="BATTLE_ART_VOXEL_FORK" then battleArtForkPresent=true end
      local lib=host.exports and host.exports.lib
      local direct=host.exports and host.exports.Voxel3D
      local v3d=nil
      if lib and type(lib.require)=="function" then
        local okv,v=pcall(lib.require,"Voxel3D")
        if okv and v and type(v.draw)=="function" then v3d=v end
      elseif direct and type(direct.draw)=="function" then
        v3d=direct
      end
      local api=host.exports and host.exports.voxel_companion

      -- Battle Art Voxel Fork 1.10.4 has its own strict companion dispatcher.
      -- Quest's v1.3.9 gameplay systems predate that dispatcher and render
      -- their follower/wild/flying actors directly through Voxel3D. Registering
      -- them into the Fork's native provider can leave the callbacks inactive
      -- even though battle integration itself works.
      --
      -- For Battle Art, keep using its PUBLIC Voxel3D implementation, but run
      -- Quest's existing v1.3.9 overworld feature callbacks through Quest's
      -- lightweight endScene adapter. This preserves the exact follower/wild/
      -- ecology code path that already works with Potato/Dramaless.
      if id=="BATTLE_ART_VOXEL_FORK" and v3d then
        Voxel3D=v3d
        rendererMod,rendererId=host,id
        return makeLocalCompanion(host,lib)
      end

      if api and tonumber(api.api)==1 and type(api.register)=="function" then
        Voxel3D=v3d or Voxel3D
        rendererMod,rendererId=host,id
        return api
      end
      if v3d then
        Voxel3D=v3d
        rendererMod,rendererId=host,id
        return makeLocalCompanion(host,lib)
      end
    end
  end
  return nil,"no supported voxel renderer found"
end


-- Quest model scale.
-- v1.06 removes ALL automatic species scaling.
-- Every Pokemon uses a half-size Quest display scale of 5.0.
-- Add manual per-National-Dex overrides here only when individually approved.
local QUEST_DEFAULT_SCALE=5.0
local QUEST_MANUAL_SCALE={
  -- [25]=4.6,   -- example only: Pikachu
  -- [150]=5.25, -- example only: Mewtwo
  -- [321]=5.0,  -- Wailord currently remains default
}

local function questDexHeightMeters(_dex)
  -- Retained as a compatibility stub for any external caller.
  -- Automatic Pokedex-height scaling is intentionally disabled.
  return nil
end

local function questSpeciesMatrixScale(dex,_model,_posedHeight)
  dex=math.floor(tonumber(dex) or 0)
  return tonumber(QUEST_MANUAL_SCALE[dex]) or QUEST_DEFAULT_SCALE
end

local function nextNaturalIdleDelay()
  return 4.0+math.random()*6.0
end

local Actor={}; Actor.__index=Actor

local function stateFor(model,name)
  local alias={idle="idle",stand="idle",idle_expression="idle_expression",walk="walk",run="walk",move="move",fly="fly",air_idle="fly",water_idle="water",water_swim="water",surf="water",entrance="entrance",battle_enter="entrance",battle_start="entrance",cry="cry",physical="physical",special="special",status="special",attack="physical",action="physical",hurt="hit",recoil="hit",faint="faint",switch="switch"}
  local state=alias[name or "idle"]
  if not state then return nil end
  return model.states and model.states[state] and state or nil
end

function Actor:setPosition(x,y,z)
  local nx=x~=nil and x or self.x; local ny=y~=nil and y or self.y; local nz=z~=nil and z or self.z
  local dx,dy,dz=(nx or 0)-(self.x or 0),(ny or 0)-(self.y or 0),(nz or 0)-(self.z or 0)
  if dx*dx+dy*dy+dz*dz>0.000001 then self._stillFor=0 end
  self.x,self.y,self.z=nx,ny,nz; return self
end
function Actor:setGroundY(v)
  self._groundY=tonumber(v)
  return self
end

function Actor:isAirborne()
  if self._groundY==nil then return false end
  return (tonumber(self.y) or 0) > self._groundY + 0.35
end

function Actor:setYaw(v) self.yaw=tonumber(v) or 0; return self end
function Actor:setPitch(v) self.pitch=tonumber(v) or 0; return self end
function Actor:setRoll(v) self.roll=tonumber(v) or 0; return self end
-- Compatibility no-op. Gameplay modules still use the native Quest model scale.
function Actor:setScale(_) return self end
function Actor:setPresentationScale(v) self._presentationScale=math.max(0,tonumber(v) or 1); return self end
function Actor:setVisible(v) self.visible=v~=false; return self end

-- Overworld Quest actor performance policy. This intentionally changes only the
-- cost of presentation; ecology/spawn/movement logic continues to run in its
-- generation-specific modules at the original cadence.
local PERF_CELL=16
local PERF_FULL_RADIUS=PERF_CELL*7
local PERF_RENDER_RADIUS=PERF_CELL*13
local PERF_SHADOW_RADIUS=PERF_CELL*7
local PERF_OUTLINE_RADIUS=PERF_CELL*6
local PERF_MEDIUM_INTERVAL=1/12
local function performancePlayerXZ()
  local ow=Game and Game.overworld
  local p=ow and ow.player
  if not p then return nil,nil end
  return tonumber(p.x),tonumber(p.z)
end
function Actor:_performanceDistanceSq()
  -- Battle actors opt out of world shadows and must always retain full-rate
  -- animation/rendering regardless of where the overworld player happens to be.
  if self.worldShadow==false then return 0 end
  local px,pz=performancePlayerXZ()
  if px==nil or pz==nil then return 0 end
  local dx=(tonumber(self.x) or 0)-px
  local dz=(tonumber(self.z) or 0)-pz
  return dx*dx+dz*dz
end
function Actor:performanceTier()
  if self.worldShadow==false then return "full" end
  local d2=self:_performanceDistanceSq()
  if d2<=PERF_FULL_RADIUS*PERF_FULL_RADIUS then return "full" end
  if d2<=PERF_RENDER_RADIUS*PERF_RENDER_RADIUS then return "medium" end
  return "sleep"
end
function Actor:shouldRender()
  return self.worldShadow==false or self:performanceTier()~="sleep"
end
function Actor:shouldOutline()
  return self.worldShadow==false or self:_performanceDistanceSq()<=PERF_OUTLINE_RADIUS*PERF_OUTLINE_RADIUS
end
function Actor:shouldShadow()
  if self.worldShadow==false then return false end
  if not shadowEnabled() then return false end
  return self:_performanceDistanceSq()<=PERF_SHADOW_RADIUS*PERF_SHADOW_RADIUS
end


local function applyState(self,state,force)
  if not state then return false end
  if force or self.state~=state then
    self.state=state; self.time=0; self.rig:setState(state); self.rig:skin(0)
  end
end

function Actor:setAnimation(name)
  name=name or "idle"
  local st=stateFor(self.model,name)
  if name=="idle" and self.requestedAnim=="idle" and (self.state==st or self._idleExpression) then
    return self
  end
  self.animName=name; self.requestedAnim=name; self.done=false
  if name=="idle" then
    self._idleExpression=false
    self._idleClock=0
    self._idleDelay=nextNaturalIdleDelay()
  else
    self._idleExpression=false
    self._idleClock=0
  end
  if not st then self.done=true; return self end
  applyState(self,st,true)
  return self
end

function Actor:update(dt)
  if self.dead then return self end
  -- Every follower/wild/ecology actor is manual=true in the overworld feature
  -- modules.  v0.7.15 therefore failed to mark the very actors the sun pass
  -- needed, while battle actors already opt out explicitly with
  -- worldShadow=false.  Mark every world-shadow actor during UPDATE, before
  -- VoxelScene runs its shadow pass.
  if self.worldShadow~=false then
    self._worldShadowTouched=(love and love.timer and love.timer.getTime and love.timer.getTime()) or os.clock()
  end
  dt=math.max(0,math.min(.1,tonumber(dt) or 0))
  -- Manual battle actors are created before the game's send-out visibility gate
  -- opens. Do not burn the entrance/idle frames while the actor is hidden.
  if self.manual and self.visible==false and (self.requestedAnim=="entrance" or self.requestedAnim=="battle_enter" or self.requestedAnim=="battle_start") then
    return self
  end
  self.time=(self.time or 0)+dt
  self._stillFor=(self._stillFor or 0)+dt
  local name=self.requestedAnim or "idle"
  -- Safety: gameplay modules normally send IDLE themselves. If a movement
  -- request stops receiving position changes, native ground idle takes over.
  if (name=="walk" or name=="run") and self._stillFor>.12 then
    local st=stateFor(self.model,"idle")
    if self.state~=st then applyState(self,st,true) end
  elseif (name=="walk" or name=="run") and self._stillFor<=.12 then
    local wanted=name
    if self.model.states and self.model.states.fly and self:isAirborne() then
      wanted="fly"
    end
    local st=stateFor(self.model,wanted)
    if self.state~=st then applyState(self,st,true) end
  end
  -- Natural idle: ground idle is the base pose. While truly idle, occasionally
  -- play one Quest personality motion once, then return to ground idle.
  if name=="idle" then
    local idleState=stateFor(self.model,"idle")
    local expressionState=stateFor(self.model,"idle_expression")
    if self._idleExpression then
      local d=self.rig:duration()
      if d<=0 or self.time>=d then
        self._idleExpression=false
        self._idleClock=0
        self._idleDelay=nextNaturalIdleDelay()
        if idleState then applyState(self,idleState,true) end
      end
    elseif self.state==idleState then
      self._idleClock=(self._idleClock or 0)+dt
      if expressionState and self._idleClock>=(self._idleDelay or nextNaturalIdleDelay()) then
        self._idleExpression=true
        self._idleClock=0
        applyState(self,expressionState,true)
      end
    end
  end

  local one=(name=="move" or name=="cry" or name=="entrance" or name=="battle_enter" or name=="battle_start" or name=="physical" or name=="special" or name=="status" or name=="attack" or name=="action" or name=="hurt" or name=="recoil" or name=="faint")
  if one then
    local d=self.rig:duration()
    if d<=0 then self.done=true; return self end
    if self.time>=d then
      if name=="faint" then self.time=d; self.done=true
      else self:setAnimation("idle") end
    end
  end
  -- Keep nearby actors at native cadence. Medium-distance actors retain smooth
  -- world movement but only deform the Quest skeleton at 12 Hz. Far actors keep
  -- their lightweight ecology position/state but sleep their skeletal rig.
  local rigDt=dt
  if self.worldShadow~=false then
    local tier=self:performanceTier()
    self._perfTier=tier
    if tier=="sleep" then
      self._perfUpdateAccum=math.min(.1,(self._perfUpdateAccum or 0)+dt)
      return self
    elseif tier=="medium" then
      self._perfUpdateAccum=(self._perfUpdateAccum or 0)+dt
      if self._perfUpdateAccum<PERF_MEDIUM_INTERVAL then return self end
      rigDt=math.min(.1,self._perfUpdateAccum)
      self._perfUpdateAccum=0
    else
      self._perfUpdateAccum=0
    end
  end
  if self.rig.update then self.rig:update(rigDt) else self.rig:skin(0) end
  return self
end

function Actor:tickNow()
  local now=(love and love.timer and love.timer.getTime and love.timer.getTime()) or os.clock()
  local dt=self._manualTickTime and math.max(0,math.min(.1,now-self._manualTickTime)) or (1/60)
  self._manualTickTime=now
  return self:update(dt)
end

function Actor:matrix(shadowOnly)
  if not shadowOnly and self.worldShadow~=false then
    self._worldShadowTouched=(love and love.timer and love.timer.getTime and love.timer.getTime()) or os.clock()
  end
  -- Floor anchor is locked from the base pose. Never derive translation from
  -- the current animated frame: wing tips / tucked feet otherwise move the
  -- entire actor up and down while flapping.
  local floor=tonumber(self._idleFloor) or tonumber(self.model.baseFloor) or tonumber(self.model.floor) or 0
  local rot=Mat4.mul(Mat4.mul(Mat4.rotateY(self.yaw or 0),Mat4.rotateX(self.pitch or 0)),Mat4.rotateZ(self.roll or 0))
  -- Fixed Quest default scale. Individual species can be changed only
  -- through QUEST_MANUAL_SCALE after visual review.
  local k=(tonumber(self._modelScale) or QUEST_DEFAULT_SCALE)*(tonumber(self._presentationScale) or 1)
  return Mat4.mul(
    Mat4.mul(
      Mat4.mul(Mat4.translate(self.x or 0,self.y or 0,self.z or 0),rot),
      Mat4.scale(k,k,k)),
    Mat4.translate(0,-floor,0))
end
function Actor:_groundShadowY()
  local gy=tonumber(self._groundY)
  if gy~=nil then return gy end
  return tonumber(self.y) or 0
end
function Actor:_ensureGroundShadowMesh()
  local g=love and love.graphics
  local img=ensureOverworldShadowImage()
  if not (g and img and self.rig) then return nil end
  -- Lock the footprint to the first stable posed girth instead of rebuilding
  -- the mesh every time a leg/wing momentarily changes the animated bounds.
  local girth=tonumber(self._shadowBaseGirth)
  if not girth or girth<=0 then
    girth=math.max(1,tonumber(self.rig.girth) or tonumber(self.model and self.model.girth) or 4)
    self._shadowBaseGirth=girth
  end
  local rx=math.min(22,math.max(2.0,girth*.62))
  local rz=math.min(12,math.max(1.2,girth*.36))
  if self._groundShadowMesh then return self._groundShadowMesh end
  local verts={};local seg=28
  local function add(px,pz,u,v) verts[#verts+1]={px,.04,pz,u,v,1} end
  for i=0,seg-1 do
    local a0=(i/seg)*math.pi*2;local a1=((i+1)/seg)*math.pi*2
    add(0,0,.5,.5)
    add(math.cos(a0)*rx,math.sin(a0)*rz,.5+.5*math.cos(a0),.5+.5*math.sin(a0))
    add(math.cos(a1)*rx,math.sin(a1)*rz,.5+.5*math.cos(a1),.5+.5*math.sin(a1))
  end
  local ok,mesh=pcall(g.newMesh,OVERWORLD_SHADOW_FORMAT,verts,"triangles","static")
  if not ok or not mesh then return nil end
  if mesh.setTexture then pcall(mesh.setTexture,mesh,img) end
  self._groundShadowMesh=mesh
  return mesh
end
function Actor:groundShadowMatrix()
  local k=.6*(tonumber(self._presentationScale) or 1)
  return Mat4.mul(Mat4.translate(self.x or 0,self:_groundShadowY(),self.z or 0),Mat4.scale(k,k,k))
end
-- Followers use the renderer's direct Voxel3D seam instead of companion mesh
-- packets. Expose the exact same shadow through that path as well.
function Actor:drawVoxelGroundShadow(Voxel3D)
  -- v0.7.18: the legacy imported-Pokemon contact ellipse is retired entirely.
  -- Battle Art already owns the world's directional sun ShadowMap.  Returning
  -- true keeps older follower code from drawing any extra black oval while the
  -- actual posed Pokemon mesh is submitted to Battle Art's caster pass below.
  return true
end

function Actor:destroy()
  if self.dead then return end
  self.dead=true; actors[self.id]=nil
  if self._groundShadowMesh and self._groundShadowMesh.release then pcall(self._groundShadowMesh.release,self._groundShadowMesh) end
  self._groundShadowMesh=nil
  if self.rig and self.rig.release then pcall(self.rig.release,self.rig) end
end
function Actor:render(context,phase,seq)
  if self.dead or not self.visible then return seq end
  if type(self.shouldRender)=="function" and not self:shouldRender() then return seq end
  seq=seq or 1
  -- v0.7.18: no synthetic contact-shadow packet. The only overworld shadow
  -- source for imported Pokemon is Battle Art's directional world ShadowMap.
  local packets,nextSeq=self.rig:drawPackets(self:matrix(),phase,"quest.main",seq)
  for _,cmd in ipairs(packets) do
    cmd.cacheKey=("quest:%d:%d:%d"):format(self.id,self.model.species or 0,cmd.sequence)
    context.draw.mesh(cmd,context)
  end
  return nextSeq
end

local API={api=1,version="0.2.2"}
function API.available() return true end
function API.load(species,variant) return Pack.load(species,variant) end
function API.createActor(species,opts)
  opts=opts or {}; species=tonumber(species)
  if not species or species<1 or species>1025 then return nil,"Pokemon Quest National Dex outside supported range" end
  local variant=tostring(opts.variant or "normal")
  local model,err=Pack.load(species,variant); if not model then return nil,err or "Pokemon Quest model unavailable" end
  local rig,rigErr=Rig.new(model); if not rig then return nil,"could not create Pokemon Quest rig: "..tostring(rigErr) end
  local id=nextId; nextId=nextId+1
  local a=setmetatable({id=id,species=species,variant=variant,model=model,rig=rig,x=opts.x or 0,y=opts.y or 0,z=opts.z or 0,yaw=opts.yaw or 0,pitch=opts.pitch or 0,roll=opts.roll or 0,visible=opts.visible~=false,manual=opts.manual==true,worldShadow=opts.worldShadow~=false,state="stand",animName="idle",requestedAnim="idle",time=0,_stillFor=999,_presentationScale=1,_modelScale=QUEST_DEFAULT_SCALE,_idleClock=0,_idleDelay=nextNaturalIdleDelay(),_idleExpression=false,dead=false},Actor)
  actors[id]=a; rig._actor=a
  -- Important for Quest: several species store their bind mesh far above/below the
  -- animated battle origin.  Charizard is one example: its raw bind mesh floor
  -- is around +62 units, while Quest idle frame 0 is near ground level.  Anchoring
  -- to the raw bind floor therefore translates the animated model underground.
  -- Establish a per-actor floor from the actual authored Quest idle pose instead.
  a:setAnimation("idle")
  if rig.skin then rig:skin(0) end
  local idleLo,idleHi=rig:posedBounds()
  a._idleFloor=tonumber(idleLo) or tonumber(model.baseFloor) or tonumber(model.floor) or 0
  local posedHeight=math.max(.001,(tonumber(idleHi) or 0)-(tonumber(idleLo) or 0))
  a._modelScale=questSpeciesMatrixScale(species,model,posedHeight)
  return a
end
function API.destroyActor(actor) if actor and actor.destroy then actor:destroy() end end
function API.variants(species) return Pack.variants(species) end
function API.hasVariant(species,variant) return Pack.hasVariant(species,variant) end
API.Mat4=Mat4
API.Voxel3D=function() return Voxel3D end
API.renderer=function() return rendererId end
API.shadowEnabled=shadowEnabled
API.performancePolicy=function()
  return {fullRadius=PERF_FULL_RADIUS,renderRadius=PERF_RENDER_RADIUS,shadowRadius=PERF_SHADOW_RADIUS,outlineRadius=PERF_OUTLINE_RADIUS,mediumHz=12}
end
API.outlineEnabled=outlineEnabled
API.toonEnabled=outlineEnabled
API.battleSceneEnabled=battleSceneEnabled
API.modelSmoothingEnabled=modelSmoothingEnabled
function API.nativeScale() return true end
function API.readAsset(path) return Pack.readAsset(path) end

_G.POKEMON_QUEST_API=API
_G.QUEST_API=API
mod.exports.quest_main=API
mod.exports.quest_importer=API
mod.exports.pokemon_quest=API

-- Battle VFX stays external; this importer owns Quest model/actor presentation APIs.

local host,err=hostApi()

-- Battle Art's player/NPC shadows are true sun ShadowMap casters. Imported Quest
-- actors are rendered through the companion/direct Voxel3D path after the
-- caster pass, so the old soft ellipse could never match the player's world
-- shadow. Hook the public ShadowMap exported by Battle Art and insert every
-- live OVERWORLD Quest mesh immediately before the pass finishes. Battle actors
-- opt out with worldShadow=false, and BattleScene signatures are left alone.
local function installBattleArtWorldShadowBridge()
  if rendererId~="BATTLE_ART_VOXEL_FORK" or not rendererMod then return false,"Battle Art Fork not selected" end
  local lib=rendererMod.exports and rendererMod.exports.lib
  if not (lib and type(lib.require)=="function") then return false,"Battle Art lib export unavailable" end
  local ok,ShadowMap=pcall(lib.require,"ShadowMap")
  if not ok or type(ShadowMap)~="table" or type(ShadowMap.stale)~="function" or type(ShadowMap.begin)~="function" or type(ShadowMap.finish)~="function" or type(ShadowMap.draw)~="function" then
    return false,"Battle Art ShadowMap unavailable"
  end
  local baseStale=rawget(ShadowMap,"__questBaseStale") or ShadowMap.stale
  local baseBegin=rawget(ShadowMap,"__questBaseBegin") or ShadowMap.begin
  local baseFinish=rawget(ShadowMap,"__questBaseFinish") or ShadowMap.finish
  ShadowMap.__questBaseStale=baseStale
  ShadowMap.__questBaseBegin=baseBegin
  ShadowMap.__questBaseFinish=baseFinish

  local passIsBattle=false
  local function battleSig(sig)
    return type(sig)=="string" and sig:sub(1,7)=="battle,"
  end
  local function q(v,step)
    v=tonumber(v) or 0;step=step or .0625
    return math.floor(v/step+.5)*step
  end
  local function shadowEligible(a)
    if not (a and not a.dead and a.worldShadow~=false and a.rig) then return false end
    if type(a.shouldShadow)=="function" then
      local ok,v=pcall(a.shouldShadow,a)
      if ok and not v then return false end
    end
    return true
  end
  local function actorStamp()
    local rows={}
    for id,a in pairs(actors) do
      if shadowEligible(a) then
        -- Shadow animation does not need to invalidate at the full 30 FPS skin
        -- cadence. A 10 FPS pose bucket keeps animated silhouettes alive while
        -- avoiding a full world ShadowMap rebuild on every wing/idle frame.
        local fr=math.floor((tonumber(a.rig.frameAt) or 0)/3)
        rows[#rows+1]=table.concat({
          tostring(id),tostring(tonumber(a.species) or 0),
          tostring(q(a.x,.125)),tostring(q(a.y,.125)),tostring(q(a.z,.125)),
          tostring(q(a.yaw,1/64)),tostring(q(a.pitch,1/64)),tostring(q(a.roll,1/64)),
          tostring(fr),tostring(a.state or "")
        },":")
      end
    end
    table.sort(rows)
    return table.concat(rows,";")
  end
  local function stamp(sig)
    if battleSig(sig) then return sig end
    return tostring(sig or "").."|quest:"..actorStamp()
  end
  local function drawCasters()
    if type(ShadowMap.sprites)=="function" then pcall(ShadowMap.sprites,true) end
    local ids={}
    local now=(love and love.timer and love.timer.getTime and love.timer.getTime()) or os.clock()
    -- Do not depend on a render/update timestamp here. Manual followers and
    -- ecology actors can be advanced from a companion seam that runs on a
    -- different side of VoxelScene's shadow update. Every live actor whose
    -- worldShadow flag is true is an overworld caster; battle actors explicitly
    -- opt out with worldShadow=false.
    for id,a in pairs(actors) do
      if shadowEligible(a) then ids[#ids+1]=id end
    end
    table.sort(ids)
    for _,id in ipairs(ids) do
      local a=actors[id]
      if shadowEligible(a) and type(a.matrix)=="function" then
        -- The actor update already produced the current dynamic meshes. Re-skinning
        -- here doubled skeletal/vertex work for every overworld Pokemon. Reuse the
        -- current posed meshes; at worst the shadow is one presentation tick behind.
        local okM,m=pcall(a.matrix,a,true)
        if okM and m then
          -- Full 3D mesh: unlike Battle Art's thin player card, do NOT snug it
          -- toward the light.  Snug exists for thin cards and moving a volume
          -- can detach the silhouette from its actual feet.
          local casted=false
          for _,part in ipairs(a.rig.parts or {}) do
            if part.mesh and part.texture then
              local okDraw=pcall(ShadowMap.draw,part.mesh,part.texture,m)
              if okDraw then casted=true end
            end
          end
          if casted then a._realShadowCastAt=now end
        end
      end
    end
    if type(ShadowMap.sprites)=="function" then pcall(ShadowMap.sprites,false) end
  end

  ShadowMap.stale=function(sig)
    passIsBattle=battleSig(sig)
    return baseStale(stamp(sig))
  end
  ShadowMap.begin=function(cx,cy,vw,vh)
    return baseBegin(cx,cy,vw,vh)
  end
  ShadowMap.finish=function(sig)
    -- Draw the imported Quest actors at the LAST possible moment while Battle
    -- Art's actual sun canvas, depth buffer and ShadowMap shader are still
    -- active. This is more reliable than drawing from begin(): every normal
    -- terrain / figure / player caster has already established the pass state,
    -- and the Pokemon are inserted immediately before Battle Art closes it.
    if not passIsBattle then pcall(drawCasters) end
    return baseFinish(stamp(sig))
  end
  ShadowMap.__questWorldShadowOwner=mod.id
  battleArtForkPresent=true
  realWorldShadowBridge=true
  if type(ShadowMap.invalidate)=="function" then pcall(ShadowMap.invalidate) end
  return true
end

local shadowOk,shadowWhy=installBattleArtWorldShadowBridge()
if rendererId=="BATTLE_ART_VOXEL_FORK" and not shadowOk and mod.log then
  if type(mod.log.warn)=="function" then mod.log:warn("Pokemon Quest world ShadowMap bridge unavailable: %s",tostring(shadowWhy))
  elseif type(mod.log.error)=="function" then mod.log:error("Pokemon Quest world ShadowMap bridge unavailable: %s",tostring(shadowWhy)) end
end

-- Export the resolved companion service through the importer so all Quest
-- gameplay modules use one renderer-neutral registration point.
mod.exports.voxel_companion=host

-- Unified gameplay modules. Keeping the QUEST_MAIN id/API means Quest continues
-- to hook the same importer exactly as before.
local function loadFeature(rel)
  local source=mod:read(rel)
  if not source then error("QUEST_MAIN: missing embedded feature "..rel,0) end
  local chunk,err=load(source,"@"..mod.path.."/"..rel)
  if not chunk then error("QUEST_MAIN feature compile error in "..rel..": "..tostring(err),0) end
  return chunk(mod)
end
loadFeature("features/Follower.lua")
loadFeature("features/StaticMapPokemonSafe.lua")
loadFeature("features/OverworldWilds.lua")
loadFeature("features/FlyingOverworld.lua")
loadFeature("features/WaterEcology.lua")
loadFeature("features/GroundEcology.lua")

if host then
  local spec={
    api=1,id="quest.main",name="Pokemon Quest Gen2",version="0.8.3-gen2-performance",priority=20,
    requires={"render_phases","world_snapshot"}, optional={},
    update=function(frame)
      local dt=(type(frame)=="table" and tonumber(frame.dt)) or 1/60
      for _,a in pairs(actors) do if not a.manual then a:update(dt) end end
    end,
    render={
      opaque_after_terrain=function(context)
        local seq=1; for _,a in pairs(actors) do seq=a:render(context,"opaque_after_terrain",seq) end
      end,
    },
    dispose=function() for _,a in pairs(actors) do if a._groundShadowMesh and a._groundShadowMesh.release then pcall(a._groundShadowMesh.release,a._groundShadowMesh) end;if a.rig then a.rig:release() end end; actors={} end,
  }
  local ok,h=pcall(host.register,spec)
  if ok then companionHandle=h elseif mod.log then mod.log:error("Quest Main companion registration failed: %s",tostring(h)) end
elseif mod.log then mod.log:error("Quest Main disabled: %s",tostring(err)) end



-- Direct Gen2 staged-battle integration. BATTLE_ART_VOXEL_GEN2 has a
-- different BattleScene signature from Gen1, so it needs its own bridge.
do
  if rendererId=="BATTLE_ART_VOXEL_GEN2" and rendererMod then
    local okBridge,Bridge=pcall(V.require,"QuestBattleGen2")
    if okBridge and Bridge then
      local ok,why=Bridge.install(rendererMod,API)
      if not ok and mod.log then
        mod.log:error("Quest Gen2 battle bridge unavailable: %s",tostring(why))
      end
    elseif mod.log then
      mod.log:error("Quest Gen2 battle bridge load failed: %s",tostring(Bridge))
    end
  elseif rendererId=="BATTLE_ART_VOXEL_FORK" and rendererMod then
    local okBridge,Bridge=pcall(V.require,"QuestBattleArtFork")
    if okBridge and Bridge then
      local ok,why=Bridge.install(rendererMod,API)
      if not ok and mod.log then
        mod.log:error("Quest Battle Art Fork bridge unavailable: %s",tostring(why))
      end
    end
  elseif rendererId=="potato_voxel" and rendererMod then
    local okBridge,Bridge=pcall(V.require,"QuestPotatoBattle")
    if okBridge and Bridge then
      local ok,why=Bridge.install(rendererMod,API)
      if not ok and mod.log then
        mod.log:error("Quest Potato battle bridge unavailable: %s",tostring(why))
      end
    end
  elseif rendererId=="DRAMALESS_SHAPE" and rendererMod then
    local okBridge,Bridge=pcall(V.require,"QuestBattleBridge")
    if okBridge and Bridge then
      local ok,why=Bridge.install(rendererMod,API)
      if not ok and mod.log then
        mod.log:error("Quest Dramaless battle bridge unavailable: %s",tostring(why))
      end
    end
  end
end
