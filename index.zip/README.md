# QuestImporterGen2

Generated locally from the user's Pokemon Quest APK.

Use together with QuestPackGen2.zip generated in the same browser session. Models are mapped by actual Pokemon identity to real National Pokedex IDs; Quest PM numbers are source IDs only. Missing species remain unavailable. Shiny and named form variants are exact and do not fall back to another model.
